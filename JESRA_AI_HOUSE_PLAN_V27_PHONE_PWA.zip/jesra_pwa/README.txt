JESRA AI HOUSE PLAN V27 — PHONE PWA

This is the phone-friendly web version.
Firebase project: jesra-ai-house-plan-v
Firebase Auth: Email/Password

IMPORTANT: Host these files on HTTPS (for example GitHub Pages, Netlify, or Firebase Hosting). Do not open index.html as a file and expect Firebase Auth/PWA installation to work.

Files:
index.html
manifest.json
sw.js
